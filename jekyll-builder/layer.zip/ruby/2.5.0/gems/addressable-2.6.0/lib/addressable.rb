# frozen_string_literal: true

require 'addressable/uri'
require 'addressable/template'
