module Git
  class Index < Git::Path
    
  end
end
