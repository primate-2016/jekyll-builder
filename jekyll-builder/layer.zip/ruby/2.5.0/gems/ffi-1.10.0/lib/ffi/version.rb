module FFI
  VERSION = '1.10.0'
end
