#ifndef FFI_STDBOOL_H
#define FFI_STDBOOL_H

typedef int bool;
#define true 1
#define false 0

#endif /* FFI_STDBOOL_H */