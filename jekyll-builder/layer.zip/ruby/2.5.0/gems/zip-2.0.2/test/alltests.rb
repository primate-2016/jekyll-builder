#!/usr/bin/env ruby

$VERBOSE = true

require 'stdrubyexttest'
require 'ioextrastest'
require 'ziptest'
require 'zipfilesystemtest'
require 'ziprequiretest'
