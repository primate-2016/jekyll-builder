module Zip
  VERSION = '2.0.2'
end
