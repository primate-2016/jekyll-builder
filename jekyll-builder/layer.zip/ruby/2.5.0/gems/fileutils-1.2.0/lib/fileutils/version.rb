# frozen_string_literal: true

module FileUtils
  VERSION = "1.2.0"
end
