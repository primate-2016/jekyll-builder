# frozen_string_literal: true

require "jekyll-sass-converter/version"
require "jekyll/converters/scss"
require "jekyll/converters/sass"

module JekyllSassConverter
end
