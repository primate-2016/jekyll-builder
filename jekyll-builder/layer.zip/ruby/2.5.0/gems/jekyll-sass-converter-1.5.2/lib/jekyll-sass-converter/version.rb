# frozen_string_literal: true

module JekyllSassConverter
  VERSION = "1.5.2".freeze
end
