module EventMachine
  module Websocket
    VERSION = "0.5.1"
  end
end
