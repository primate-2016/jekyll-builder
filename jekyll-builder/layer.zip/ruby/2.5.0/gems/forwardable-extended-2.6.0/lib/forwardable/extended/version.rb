# Frozen-string-literal: true
# Copyright: 2015-2016 Jordon Bedwell - MIT License
# Encoding: utf-8

module Forwardable
  module Extended
    VERSION = "2.6.0"
  end
end
