# Path Traversal Samples

Copied from https://github.com/tuzovakaoff/zip_path_traversal on 2018-08-25.
